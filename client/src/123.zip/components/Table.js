import React from "react";

import "./Table.css"
const Table = () => {
    return (
        <>
        <div className="a2">
            <input placeholder="PPP ID" className="PPPID"></input>
            <img src="search1.jpeg" className="i1"></img>
            <a href="/p1"><button className="btn3">Add property</button></a>
        </div>
<div className="body">
<table className="Table"  >
                <tr className="inside table">
                <td className="cell">PPP ID</td>
                <td className="cell">Image</td>
                <td className="cell">Property</td>
                <td className="cell">contact</td>
                <td className="cell">Area</td>
                <td className="cell">views</td>
                <td className="cell">status</td>
                <td className="cell">Days left</td>
                <td className="cell">Action</td>
                </tr> 

                <tr className="inside table">
                <td className="cell">PPP ID</td>
                <td className="cell">Image</td>
                <td className="cell">Property</td>
                <td className="cell">contact</td>
                <td className="cell">Area</td>
                <td className="cell">views</td>
                <td className="cell">status</td>
                <td className="cell">Days left</td>
                <td className="cell">Action</td>
                </tr> 


                <tr className="inside table">
                <td className="cell">PPP ID</td>
                <td className="cell">Image</td>
                <td className="cell">Property</td>
                <td className="cell">contact</td>
                <td className="cell">Area</td>
                <td className="cell">views</td>
                <td className="cell">status</td>
                <td className="cell">Days left</td>
                <td className="cell">Action</td>
                </tr> 


                <tr className="inside table">
                <td className="cell">PPP ID</td>
                <td className="cell">Image</td>
                <td className="cell">Property</td>
                <td className="cell">contact</td>
                <td className="cell">Area</td>
                <td className="cell">views</td>
                <td className="cell">status</td>
                <td className="cell">Days left</td>
                <td className="cell">Action</td>
                </tr> 


                <tr className="inside table">
                <td className="cell">PPP ID</td>
                <td className="cell">Image</td>
                <td className="cell">Property</td>
                <td className="cell">contact</td>
                <td className="cell">Area</td>
                <td className="cell">views</td>
                <td className="cell">status</td>
                <td className="cell">Days left</td>
                <td className="cell">Action</td>
                </tr> 


                <tr className="inside table">
                <td className="cell">PPP ID</td>
                <td className="cell">Image</td>
                <td className="cell">Property</td>
                <td className="cell">contact</td>
                <td className="cell">Area</td>
                <td className="cell">views</td>
                <td className="cell">status</td>
                <td className="cell">Days left</td>
                <td className="cell">Action</td>
                </tr> 

                <tr className="inside table">
                <td className="cell">PPP ID</td>
                <td className="cell">Image</td>
                <td className="cell">Property</td>
                <td className="cell">contact</td>
                <td className="cell">Area</td>
                <td className="cell">views</td>
                <td className="cell">status</td>
                <td className="cell">Days left</td>
                <td className="cell">Action</td>
                </tr> 
                <tr className="inside table">
                <td className="cell">PPP ID</td>
                <td className="cell">Image</td>
                <td className="cell">Property</td>
                <td className="cell">contact</td>
                <td className="cell">Area</td>
                <td className="cell">views</td>
                <td className="cell">status</td>
                <td className="cell">Days left</td>
                <td className="cell">Action</td>
                </tr> 
                      
                {
              







                }




                
                
                </table>
              
         </div> 
              
        </>
      );
    };

    
    
    export default Table;